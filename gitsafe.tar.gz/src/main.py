from bitsafe import BitSafeCLI
if __name__ == "__main__":
    bsafe = BitSafeCLI()